# QodeX Landing Page

**Pre-sell landing page for QodeX Inner Circle iOS app**

## 🚀 Quick Deploy Options

### Option 1: Vercel Drag & Drop (Fastest - 2 minutes)
1. Go to https://vercel.com/new
2. Drag this folder onto the page
3. Click "Deploy"
4. Done! 🎉

### Option 2: GitHub + Vercel (Recommended)
1. Create GitHub repo: `qodex-landing`
2. Push this code:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/qodex-landing.git
   git branch -m main
   git push -u origin main
   ```
3. Go to https://vercel.com/new → Import from GitHub
4. Deploy automatically

### Option 3: Vercel CLI
```bash
npm i -g vercel
vercel --prod
```

## 📁 Structure

```
landing-page/
├── index.html          # Main page
├── package.json        # Config
├── vercel.json         # Vercel settings
├── DEPLOY.md           # Detailed guide
├── VISUAL_PREVIEW.md   # Design reference
└── .github/workflows/  # Auto-deployment
    └── deploy.yml
```

## 🎨 Features

- ✅ Cosmic black design (matches iOS app)
- ✅ 4-tier pricing display
- ✅ Email waitlist capture
- ✅ Mobile responsive
- ✅ SEO optimized
- ✅ Fast loading

## 📊 Pricing Displayed

| Tier | Price | Description |
|------|-------|-------------|
| Free | $0 | Basic calculator |
| Seeker | $9.99/mo | Full chart + community |
| Initiate | $29.99/mo | Live sessions |
| Master | $99/mo | 1:1 with Shani |

## 🎯 Purpose

Validate pricing before iOS app launch:
- Track waitlist signups
- Measure tier interest
- Gather beta users
- Build launch momentum

## 🔗 Connect to Custom Domain

After deployment:
1. Vercel Dashboard → Project Settings → Domains
2. Add: `qodex.academy` or `www.qodex.academy`
3. Update DNS records as instructed

## 📈 Analytics Setup (Optional)

Add to `<head>` in index.html:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
```

## 📝 Notes

- Static HTML/CSS/JS - no backend needed
- Form submissions currently console.log (add backend later)
- Images are CSS-generated (no external assets)

---

**Built by Asaf & Shani**
