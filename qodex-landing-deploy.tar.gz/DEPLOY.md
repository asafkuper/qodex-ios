# QodeX Landing Page - Deployment Guide

## Option 1: Vercel CLI (Recommended)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login (opens browser)
vercel login

# 3. Deploy
vercel --prod
```

## Option 2: Vercel Dashboard (Easiest)

1. Go to https://vercel.com/new
2. Import from GitHub (create repo first)
3. Or drag-and-drop the `landing-page` folder
4. Deploy instantly

## Option 3: GitHub + Vercel Integration

```bash
# 1. Create GitHub repo
git init
git add .
git commit -m "Initial landing page"
git remote add origin https://github.com/YOUR_USERNAME/qodex-landing.git
git push -u origin main

# 2. Connect Vercel to GitHub
# Go to vercel.com → New Project → Import from GitHub
```

## Files to Deploy

```
landing-page/
├── index.html      # Main page
├── package.json    # Project config
└── vercel.json     # Vercel config
```

## Custom Domain Setup

1. Deploy first
2. Go to Vercel dashboard → Project Settings → Domains
3. Add: qodex.academy
4. Update DNS records as instructed

## Environment Variables (if needed)

```bash
# For waitlist backend (optional)
vercel env add EMAIL_API_KEY
```

## Post-Deploy Checklist

- [ ] Site loads correctly
- [ ] Waitlist form works
- [ ] Mobile responsive
- [ ] Custom domain connected
- [ ] SSL certificate active
- [ ] Analytics installed (optional)

---

**Current Status**: Ready to deploy
**Location**: `/root/.openclaw/workspace/qodex-ios/landing-page/`
