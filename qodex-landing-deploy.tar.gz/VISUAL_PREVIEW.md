# QODEX LANDING PAGE — VISUAL PREVIEW

## 🌌 HERO SECTION (Full Screen)

```
┌─────────────────────────────────────────────────────────────┐
│  ✦ QodeX                                    [Coming Soon]   │
│                                                             │
│                                                             │
│         Decode Your                                         │
│         ╔═══════════════════════════════════════╗          │
│         ║    E N E R G E T I C   M A T R I X    ║          │
│         ╚═══════════════════════════════════════╝          │
│                                                             │
│    The numerology app that reveals the blueprint you        │
│    were born with. Not intuition. Not prediction.           │
│    Precise structural DeCoding.                             │
│                                                             │
│    👤 👤 👤 👤     500+ seekers on the waitlist             │
│                                                             │
│    ┌─────────────────────────────────────────┐               │
│    │  [Enter your email    ]  [Join Waitlist]│               │
│    └─────────────────────────────────────────┘               │
│                                                             │
│    Be the first to know. See pricing →                      │
│                                                             │
│  ✨ ✨ ✨ Animated stars in background ✨ ✨ ✨              │
└─────────────────────────────────────────────────────────────┘
```

---

## 💰 PRICING SECTION

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              Choose Your Path                               │
│              Start free. Upgrade when you're ready.         │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │   FREE   │  │  SEEKER  │  │ INITIATE │  │  MASTER  │   │
│  │          │  │[POPULAR] │  │          │  │          │   │
│  │   $0     │  │  $9.99   │  │ $29.99   │  │  $99     │   │
│  │  /month  │  │  /month  │  │  /month  │  │  /month  │   │
│  │          │  │          │  │          │  │          │   │
│  │ ✓ Basic  │  │ ✓ Full   │  │ ✓ Weekly │  │ ✓ 1:1    │   │
│  │ ✓ 1 Qode │  │ ✓ Daily  │  │   live   │  │  Shani   │   │
│  │   /week  │  │   Qodes  │  │ ✓ Library│  │ ✓ WhatsApp│  │
│  │ ✗ —      │  │ ✓ Comm.  │  │ ✓ Compat.│  │ ✓ Retreat│   │
│  │ ✗ —      │  │ ✗ —      │  │ ✗ —      │  │          │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## ✨ FEATURES SECTION

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              What You'll Get                                │
│              Tools to understand yourself                   │
│                                                             │
│     📊              📅              👥                      │
│   Full Chart     Daily Qodes     Community                  │
│   Analysis       Personalized    Connect with               │
│                  Guidance        fellow seekers             │
│                                                             │
│     🎥              📚              💫                      │
│   Live Sessions  Teachings       Compatibility              │
│   With Shani     Library         Understand                 │
│                  Video courses   relationships              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 👤 SHANI SECTION

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    ✦ (Avatar)                               │
│                                                             │
│              Meet Shani                                     │
│                                                             │
│    "I combine deep intuition with analytical precision      │
│     to read the codes that shape your reality. This is      │
│     not fortune-telling. It is a structural examination     │
│     of the energetic patterns that influence every          │
│     aspect of your existence."                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## ❓ FAQ SECTION

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│              Questions?                                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  When will the app launch?                    [+]   │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Is there a free trial?                       [+]   │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  What makes QodeX different?                  [+]   │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Can I switch tiers?                          [+]   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🦶 FOOTER

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   [Privacy]  [Terms]  [Contact]  [Instagram]                │
│                                                             │
│        Built with intention by Shani & Asaf                 │
│                                                             │
│           © 2026 QodeX Academy                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎨 DESIGN SYSTEM

| Element | Value |
|---------|-------|
| **Background** | Cosmic black #0A0A0F |
| **Cards** | Deep space #12121A |
| **Accent** | Gold #D4AF37 |
| **Text** | White #F5F5F5 |
| **Secondary** | Gray #A0A0B0 |
| **Stars** | Animated twinkling |
| **Font** | System sans-serif |
| **Feel** | Premium, mystical, trustworthy |

---

## 📱 RESPONSIVE

**Desktop**: 4 pricing cards side by side
**Tablet**: 2x2 grid
**Mobile**: Stacked vertically

---

## ✨ INTERACTIONS

- **Stars**: Twinkle animation (CSS)
- **Buttons**: Hover lift + gold glow
- **Cards**: Hover border highlight
- **FAQ**: Click to expand/collapse
- **Form**: Success message on submit

---

## 🎯 CONVERSION ELEMENTS

1. **Social proof**: "500+ seekers" (credibility)
2. **Urgency**: "Coming Soon" (scarcity)
3. **Low friction**: Email only (easy signup)
4. **Clear pricing**: No surprises (trust)
5. **Shani's face**: Personal connection (warmth)

---

**This is what your landing page looks like.**

Ready to deploy?
