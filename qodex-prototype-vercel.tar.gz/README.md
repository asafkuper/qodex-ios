# QodeX Prototype - Vercel Deployment

## Quick Deploy (2 minutes)

### Option 1: Vercel CLI

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login to Vercel
vercel login

# 3. Navigate to project
cd /path/to/qodex-ios/vercel-deploy

# 4. Deploy
vercel --prod
```

### Option 2: GitHub + Vercel (Recommended)

```bash
# 1. Create new GitHub repo
cd /path/to/qodex-ios/vercel-deploy
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/qodex-prototype.git
git push -u origin main

# 2. Go to https://vercel.com/new
# 3. Import your GitHub repo
# 4. Click Deploy
```

### Option 3: Vercel Web Interface

1. Go to https://vercel.com/new
2. Upload the `vercel-deploy` folder as a zip
3. Click Deploy

---

## Files Included

- `index.html` - The prototype (renamed from prototype.html)
- `package.json` - Vercel configuration

---

## After Deployment

Your prototype will be live at:
`https://qodex-prototype-YOUR_USERNAME.vercel.app`

---

## Custom Domain (Optional)

1. Go to Vercel Dashboard → Project → Settings → Domains
2. Add your domain
3. Update DNS records as instructed
